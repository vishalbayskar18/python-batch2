
'''
d1 = {1:1, 2:4, 3:5}

d1 = dict()

d1.update({6:5})

s1 = {1,2,1,1}

s2 = set()

s2.add()

print (type(s1))

new = {}

print(type(new))

d1 = {5:'one', 2 : 'two'}
print (d1[5])

print (d1.get(1, 0))

print (d1.get(2, 0))

l1 = [1,2,3,1,1,1, "vishal", "anurag", "rohit", "rohit"]

d1 = {}

for i in l1:
    value = d1.get(i, 0)
    d1[i] = value + 1

print (d1)
import time

for i in l1:
    if not i in d1:
        d1[i] = 1
        #time.sleep(2)
    else:
        d1[i] = d1[i] + 1

    print (d1)

a = [1, 1, 1, 1, 2, 3, 4, 3, 2, 5, 5, 5, 5, 2, 2, 2, 2, 3, 6, 6, 7, 7, 7, 8, 9]

count_dict = dict()

for value in a:
    count_dict[value] = a.count(value)

print(count_dict)

import sys

s1 = "my name is khan"

value = s1.split()[-1].split('a')

print (value)

result = s1.split('a', 1)
print (result)

result = s1.split('a')
print (result)

result = s1.startswith("m")

print (result)
str1 = "Koi Mil Gaya"

for i in str1:
    print (i)

print(str1[0:3])

l1 = ["Hritik", "Akshay", "Amir", "Ajay"]

res = ' and '.join(l1)

print (res)

for i in range(2, 10, 2):
    print (i)

def sayHello(n, name="Rahul"):

    for i in range(n):
        print ("Hello ", name)

sayHello(5, "Rohit")
sayHello(5)

'''

import sys

def sum(hostname, user, password, databseName = "", table=""):

    print (hostname + user + password)
    print (databseName, table)


#sum("vishal", "localhost", "password123",  table="Table1", databseName="myDB2")


#sys.exit()

def sayHello(n, *names, **rest):

    print ("names = ", names)
    print ("type of name ", type(names))
    #for name in names:
    #    print ("Hello ", name)

    print ("Rest = ", rest)
    print("type of rest ", type(rest))

    #for i in range(n):
    #    print ("Hello ")

#sayHello(5, "Rohit", "Rahul", "Mukund", age=20, salary='2.0Crs')
#sayHello(5)
d1={"age" : 29, "Salary" : "2.2Cr"}

sayHello(5, 2,3,4, **d1)

#for i in [1,2,3,6]:
#    print (i)







