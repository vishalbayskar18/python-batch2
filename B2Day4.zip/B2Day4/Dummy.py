def sum(a, b, *c, **d):

    sumD = 0
    for k,v in d.items():
        print (k, v)
        sumD = sumD + d[k]

    sumC = 0
    for i in c:
        sumC = sumC + i

    return a + b + sumC + sumD

result = sum(1,2, 3,4, arg1=10, arg2=20)

print(result)