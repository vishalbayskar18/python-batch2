

def getDBConnection(user, password, hostname, dbName):

    print ("Connect to hostname ", hostname)

    print ("using user name ", user, " and password " ,
           password)

    print("To dbName", dbName)


d1 = {"hostname" : "127.0.0.1", "user" : "nikhil",
      "password" : "nikhil", "dbName" : "Sample DB"}

getDBConnection(**d1)